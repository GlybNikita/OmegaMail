package com.example.omegamail;

public class User {
    public String id, name, email;

    public User(String id, String name, String email) {
        this.email = email;
        this.name = name;
        this.id = id;
    }
}
